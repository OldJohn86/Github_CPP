/*
 * base64.h
 *
 * Base-64 routines.
 *
 * $Id: base64.h,v 1.2 2001/03/15 08:33:05 dugsong Exp $
 */

#ifndef BASE64_H
#define BASE64_H

int	base64_pton(char const *, u_char *, size_t);

#endif /* BASE64_H */

