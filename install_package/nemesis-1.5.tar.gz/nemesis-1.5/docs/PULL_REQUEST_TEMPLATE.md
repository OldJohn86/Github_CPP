Fix issue #1234: short description

## Proposed Changes

  - Added option ...
  - Updated README ...
  - Updated man page(s)

